#include "stack.hpp"
#include <iostream>


// Push operation to insert an element on top of stack.
void Stack::Push(int x)
{
   
};
// This function will return (true) if stack is empty, (false) otherwise
bool Stack::IsEmpty()
{
    
};
// Pop operation to remove an element from top of stack.
void Stack::Pop()
{
    
};

// print elements in container
void Stack::Print()
{
    
};