/*
 * rectangle.cpp
 * CSC 116 Fall 2019 - Lab 08
 */

#include "rectangle.hpp"

// student must implement this constructor
Rectangle::Rectangle(Point const & min, Point const & max) {
}

// student must implement this constructor
Rectangle::Rectangle(double x, double y, double width, double height) {
}

double Rectangle::area() const {
    // student code here
}

double Rectangle::perimeter() const {
    // student code here
}

Point Rectangle::center() const {
    // student code here
}

std::string Rectangle::name() const {
    // student code here
}

double Rectangle::width() const {
    // student code here
}

double Rectangle::height() const {
    // student code here
}

Point Rectangle::getMin() const {
	// student code here
}

Point Rectangle::getMax() const {
	// student code here
}
