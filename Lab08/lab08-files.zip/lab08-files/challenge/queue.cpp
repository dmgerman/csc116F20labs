#include "queue.hpp"
#include <iostream>
#include <vector>
// Pop operation to remove last element from stack.
void Queue::Pop() {
   
}