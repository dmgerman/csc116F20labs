#pragma once
#include "stack.hpp"

// Queue class inherites Stack.
class Queue: public Stack
{
public:
    
    void Pop();
};
