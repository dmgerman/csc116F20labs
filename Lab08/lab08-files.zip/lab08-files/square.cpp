#include "square.hpp"

// student must implement this constructor
Square::Square(Point const & min, double width) {
}
