#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <stdexcept>


class Queue {
public:

    /* Add push, pop and size methods here */

private:

    /* Add private data here */

};